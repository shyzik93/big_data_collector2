import os.path

# указываем пути

cdir = os.path.dirname(__file__)

sets = {
    'db_dump_to': os.path.join(cdir, 'dump.sql'),
    'db_type': 'sqlite3',
    'db_sets': {
        'sqlite3': {
            'path': os.path.join(cdir, 'main.db'),
        },
        'mysql': {
            'server': None,
            'port': None,
            'user': None,
            'password': None,
        }
    },
    'path_row_data': os.path.join(cdir, 'row_data'),
}
