from init import sets
import pydb

db = pydb.DB(sets)

if __name__ == '__main__':
    db.db.export(sets['db_dump_to'])
    print(db.db)