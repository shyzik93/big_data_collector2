class SSimple:

    def __init__(self, db, c, uniq_keys):
        self.db = db
        self.c = c

    def add_row(self, fields):

        pass