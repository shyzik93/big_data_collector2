import sqlite3

class DBBinder:

    def __init__(self, sets_db):

        self.c = sqlite3.connect(sets_db['path'])
        self.c.row_factory = sqlite3.Row
        self.cu = self.c.cursor()

    def execute(self, sql, values=None):

        return self.cu.execute(sql, values)

    def export(self, to_file):

        with open(to_file, "w") as f:
            for line in self.c.iterdump():
                f.write("%s\n" % line)

    def commit(self):

        self.c.commit()