from init import sets
import pydb

db = pydb.DB(sets)

if __name__ == '__main__':
    print(db.db)