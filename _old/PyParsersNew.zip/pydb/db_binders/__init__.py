def get_db_binder(db_type_name, sets):
    module = __import__('binder_'+db_type_name)
    return dir(module)['DBBinder'](sets['db_type_name'])