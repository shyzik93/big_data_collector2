import sqlite3

class DBBinder:

    def __init__(self, sets_db):

        self.c = sqlite3.connect(sets_db['path'])
        self.c.row_factory = sqlite3.Row
        self.cu = self.c.cursor()

    def query(self, sql):

        pass

    def export(self, f):

        pass

    def commit(self):

        pass