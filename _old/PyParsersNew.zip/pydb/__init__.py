import struct_simple
import db_binders

class DB:

    def __init__(self, sets):

        self.sets = sets

        self.db = db_binders.get_db_binder(sets['db_type'], sets['db'][sets['db_type']])

