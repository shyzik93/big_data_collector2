BEGIN TRANSACTION;
CREATE TABLE `domain` (
    `domain_name` VAR(255) NOT NULL UNIQUE,
    `domain_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `domain_is_deleted` INTEGER NOT NULL DEFAULT '0',
    `domain_date_add` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE `schema` (
    `schema_name` VAR(255) NOT NULL UNIQUE,
    `schema_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `schema_is_deleted` INTEGER NOT NULL DEFAULT '0',
    `schema_date_add` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE `source_url` (
    `source_url_schema_id` INTEGER NOT NULL,
    `source_url_domain_id` INTEGER NOT NULL,
    `source_url_path` VAR(255) NOT NULL,
    `source_url_title_id` INTEGER NOT NULL,
    `source_url_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `source_url_is_deleted` INTEGER NOT NULL DEFAULT '0',
    `source_url_date_add` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(source_url_schema_id) REFERENCES schema(schema_id),
    FOREIGN KEY(source_url_domain_id) REFERENCES domain(domain_id),
    FOREIGN KEY(source_url_title_id) REFERENCES title(title_id)
);
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('title',3);
CREATE TABLE `title` (
    `title_name` VAR(255) NOT NULL UNIQUE,
    `title_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `title_is_deleted` INTEGER NOT NULL DEFAULT '0',
    `title_date_add` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO "title" VALUES('ыыввв',1,0,'2019-09-15 11:18:21');
INSERT INTO "title" VALUES('длрв ег впл',2,0,'2019-09-15 11:18:21');
INSERT INTO "title" VALUES('оооооо',3,0,'2019-09-15 11:18:21');
COMMIT;
